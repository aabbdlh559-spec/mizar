package com.example.zira;

import android.inputmethodservice.InputMethodService;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.InputConnection;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;

public class ZiraIME extends InputMethodService {
    private final StringBuilder buf = new StringBuilder();
    private boolean secret = true;
    private Button modeBtn;

    private static final String[] ROWS = {
        "ضصثقفغعهخحج",
        "شسيبلاتنمك",
        "ذظطزرودئءؤ"
    };

    @Override
    public View onCreateInputView() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF1B1B22);
        root.setPadding(4, 8, 4, 8);

        for (int i = 0; i < ROWS.length; i++) {
            LinearLayout r = newRow();
            for (char ch : ROWS[i].toCharArray()) {
                final char c = ch;
                r.addView(key(String.valueOf(c), 1f, v -> typeChar(c)));
            }
            if (i == ROWS.length - 1) {
                r.addView(key("⌫", 1.4f, v -> backspace()));
            }
            root.addView(r);
        }

        LinearLayout last = newRow();
        modeBtn = key("سري ✓", 1.6f, v -> toggleMode());
        last.addView(modeBtn);
        last.addView(key("فك", 1.2f, v -> decodeBeforeCursor()));
        last.addView(key("،", 1f, v -> punct("،")));
        last.addView(key("مسافة", 3f, v -> space()));
        last.addView(key(".", 1f, v -> punct(".")));
        last.addView(key("؟", 1f, v -> punct("؟")));
        last.addView(key("↵", 1.4f, v -> enter()));
        root.addView(last);
        return root;
    }

    private LinearLayout newRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.setLayoutParams(new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 130));
        return r;
    }

    private Button key(String label, float weight, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(18);
        b.setAllCaps(false);
        b.setTextColor(0xFFFFFFFF);
        b.setBackgroundColor(0xFF33333F);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, 0, 0, 0);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0,
            LinearLayout.LayoutParams.MATCH_PARENT, weight);
        p.setMargins(3, 3, 3, 3);
        b.setLayoutParams(p);
        b.setOnClickListener(l);
        return b;
    }

    private void typeChar(char c) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (secret) {
            buf.append(c);
            ic.setComposingText(buf, 1);
        } else {
            ic.commitText(String.valueOf(c), 1);
        }
    }

    private void flush() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null || buf.length() == 0) return;
        ic.commitText(ZiraCodec.encodeWord(buf.toString()), 1);
        buf.setLength(0);
    }

    private void space() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.commitText(" ", 1);
    }

    private void punct(String p) {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.commitText(p, 1);
    }

    private void enter() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_ENTER));
        ic.sendKeyEvent(new KeyEvent(KeyEvent.ACTION_UP, KeyEvent.KEYCODE_ENTER));
    }

    private void backspace() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        if (buf.length() > 0) {
            buf.deleteCharAt(buf.length() - 1);
            if (buf.length() == 0) ic.commitText("", 1);
            else ic.setComposingText(buf, 1);
        } else {
            ic.deleteSurroundingText(1, 0);
        }
    }

    private void toggleMode() {
        flush();
        secret = !secret;
        modeBtn.setText(secret ? "سري ✓" : "عادي");
    }

    private void decodeBeforeCursor() {
        InputConnection ic = getCurrentInputConnection();
        if (ic == null) return;
        flush();
        CharSequence t = ic.getTextBeforeCursor(500, 0);
        if (t == null || t.length() == 0) return;
        Toast.makeText(this, ZiraCodec.decodeText(t.toString()), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onFinishInputView(boolean finishingInput) {
        buf.setLength(0);
        super.onFinishInputView(finishingInput);
    }
}
