package com.example.zira;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private EditText input;
    private TextView output;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setPadding(40, 40, 40, 40);

        TextView title = new TextView(this);
        title.setText("ميزار\nكيبورد ومترجم لغتنا السرية");
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        root.addView(title);

        root.addView(button("1) تفعيل الكيبورد", v ->
            startActivity(new Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))));
        root.addView(button("2) اختيار الكيبورد", v ->
            ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).showInputMethodPicker()));

        input = new EditText(this);
        input.setHint("اكتب أو الصق النص هنا");
        input.setMinLines(3);
        input.setGravity(Gravity.TOP | Gravity.START);
        root.addView(input);

        root.addView(button("عربي ← لغتنا", v ->
            output.setText(ZiraCodec.encodeText(input.getText().toString()))));
        root.addView(button("لغتنا ← عربي", v ->
            output.setText(ZiraCodec.decodeText(input.getText().toString()))));

        output = new TextView(this);
        output.setTextSize(18);
        output.setTextIsSelectable(true);
        output.setPadding(0, 24, 0, 24);
        root.addView(output);

        root.addView(button("نسخ النتيجة", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("mizar", output.getText()));
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show();
        }));

        root.addView(button("للتواصل مع المطور: +967 739 656 992", v ->
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/967739656992")))));

        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);
    }

    private Button button(String text, View.OnClickListener l) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setOnClickListener(l);
        return btn;
    }
}
